from django.shortcuts import render, redirect
from django.contrib.auth.hashers import make_password
from store.models.product import Product
from store.models.category import Category
from store.models.customer import Customer
from django.views import View


class Signup(View):
    def get(self, request):
        return render(request, 'signup.html')
    
    def post(self, request):
        first_name = request.POST.get("firstname")
        last_name = request.POST.get("lastname")
        mobile = request.POST.get("mobile")
        email = request.POST.get("email")
        password = request.POST.get("password")

        # validation

        value = {
            'first_name' : first_name,
            'last_name' : last_name,
            'mobile' : mobile,
            'email' : email,        
        }

        error_message = None

        customer = Customer(first_name=first_name, last_name=last_name, mobile=mobile,email=email,password=password)

        error_message = self.validateCustomer(customer)

        # for save
        if not error_message:
            print(first_name, last_name, mobile, email, password)
            customer.password = make_password(customer.password)
            customer.save()
            # cust.register() # call overridden method
            return redirect("index")
        else:
            data = {"error": error_message, "values": value}        
            return render(request, 'signup.html', data)
        
    def validateCustomer(self, customer):
        error_message = None
        if not customer.first_name:
            error_message = "firstname is required"
        elif len(customer.first_name) < 4:
            error_message = "firstname must be 4 char long or more "
        elif not customer.last_name:
            error_message = "lastname is required"
        elif len(customer.last_name) < 4:
            error_message = "firstname must be 4 char long or more "
        elif not customer.mobile:
            error_message = "mobile number is required"
        elif len(customer.mobile) < 10:
            error_message = "mobile number must be 10 char or more"
        elif not customer.email:
            error_message = "email is required"
        elif len(customer.email) < 4:
            error_message = "email must be 4 char long or more"
        elif not customer.password:
            error_message = "password is required"
        elif len(customer.password) < 6:
            error_message = "password must be 6 char long or more"
        elif customer.isExists(): # call overridden method to check email already register or not   
            error_message = "Email address already registered" 

        return error_message