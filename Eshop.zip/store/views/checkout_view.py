from django.views import View
from django.shortcuts import render, redirect
from store.models.product import Product
from store.models.order import Order
from store.models.customer import Customer

class CheckOut(View):
    def post(self, request):
        address = request.POST.get('address')
        mobile = request.POST.get('mobile')
        customer = request.session.get('customer')
        cart = request.session.get('cart')
        products = Product.get_products_by_id(list(cart.keys()))
        print(address, mobile, customer, cart, products)

        for product in products:
            print(cart.get(str(product.id)))
            order = Order(customer = Customer(id=customer),
                          product=product,
                          price=product.price,
                          address=address,
                          mobile=mobile,
                          quantity=cart.get(str(product.id)))
            order.save()
        request.session['cart'] = {}
            # print(order.placeOrder())
                          
        return redirect("cart")