from django.shortcuts import render, redirect
from django.contrib.auth.hashers import check_password
from store.models.customer import Customer
from django.views import View
from django.http import HttpResponseRedirect


class LoginView(View):
    returnUrl = None
    def get(self, request):
        LoginView.return_url = request.GET.get('return_url')
        return render(request, 'login.html')

    def post(self, request):
        email = request.POST.get("email")
        password = request.POST.get("password")
        customer = Customer.get_customer_by_email(email)
        
        error_message = None

        if customer:
            flag = check_password(password, customer.password)
            if flag:
                request.session['customer'] = customer.id
                
                if LoginView.return_url:
                    return HttpResponseRedirect(LoginView.return_url)
                else:
                    LoginView.return_url = None            
                    return redirect("index")
            
            else:
                error_message = "Email or password invalid..!!"
        else:
            error_message = "Email or password invalid..!!"

        print(email, password)
        return render(request,'login.html', {"error": error_message})
    

def logout(request):
    request.session.clear()
    return redirect("login")
