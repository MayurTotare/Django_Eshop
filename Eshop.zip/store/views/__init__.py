from store.views import home_view
from store.views import login_view
from store.views import signup_view