# exec(open(r"C:\Users\dell\Eshop\store\db_shell.py").read())

from store.models.product import Product


# print(Product.get_all_products())

# print(Product.get_all_products())

